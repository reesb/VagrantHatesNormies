# VagrantHatesNormies
NORMIES GET OUT REEEEEEEEEEEEEEEEEEEEEEEEEEE

(Replaces the vagrant charge attack sound effect with the reee screech)

## Changelog

### 1.1.0
- Updated to work with R2API 3.0

### 1.0.0
- Initial release